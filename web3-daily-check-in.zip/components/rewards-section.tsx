"use client"

import { motion } from "framer-motion"
import { Coins, Sparkles, Award } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useStore } from "@/lib/store"
import { getTranslations } from "@/lib/i18n"

export function RewardsSection() {
  const { locale } = useStore()
  const t = getTranslations(locale)

  const rewards = [
    {
      icon: Coins,
      title: t.rewards?.tokensTitle || "ARC Tokens",
      description: t.rewards?.tokensDesc || "Earn native tokens with every check-in",
      badge: "Daily",
      color: "from-primary via-primary/80 to-primary/60",
      image: "/crypto-tokens-gold-coins.jpg",
      glow: "group-hover:shadow-primary/50",
    },
    {
      icon: Sparkles,
      title: t.rewards?.nftsTitle || "Exclusive NFTs",
      description: t.rewards?.nftsDesc || "Unlock rare NFTs by maintaining streaks",
      badge: "Streak Bonus",
      color: "from-accent via-accent/80 to-accent/60",
      image: "/colorful-nft-digital-art.jpg",
      glow: "group-hover:shadow-accent/50",
    },
    {
      icon: Award,
      title: t.rewards?.badgesTitle || "Achievement Badges",
      description: t.rewards?.badgesDesc || "Collect special badges for milestones",
      badge: "Limited",
      color: "from-secondary via-secondary/80 to-secondary/60",
      image: "/achievement-badges-medals.jpg",
      glow: "group-hover:shadow-secondary/50",
    },
  ]

  return (
    <section className="py-20 bg-muted/30 relative overflow-hidden">
      {/* Decorative background */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(99,102,241,0.3),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_50%,rgba(236,72,153,0.3),transparent_50%)]" />
      </div>

      <div className="container mx-auto px-4 relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4 text-balance">{t.rewards?.title || "Exclusive Rewards"}</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto text-pretty">
            {t.rewards?.subtitle || "Multiple ways to earn and unlock valuable rewards"}
          </p>
        </motion.div>

        <div className="grid gap-8 md:grid-cols-3 max-w-6xl mx-auto">
          {rewards.map((reward, index) => (
            <motion.div
              key={reward.title}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15 }}
            >
              <Card
                className={`group relative overflow-hidden border-2 hover:border-transparent transition-all duration-500 h-full ${reward.glow} hover:shadow-2xl`}
              >
                {/* Animated gradient border */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${reward.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}
                />
                <div className="absolute inset-[2px] bg-card rounded-[calc(var(--radius)-2px)]" />

                <CardContent className="p-0 relative">
                  {/* Image with overlay */}
                  <div className="relative overflow-hidden">
                    <motion.img
                      whileHover={{ scale: 1.1 }}
                      transition={{ duration: 0.6 }}
                      src={reward.image}
                      alt={reward.title}
                      className="w-full h-56 object-cover"
                    />
                    <div
                      className={`absolute inset-0 bg-gradient-to-t ${reward.color} opacity-20 group-hover:opacity-40 transition-opacity`}
                    />

                    {/* Badge overlay */}
                    <Badge className="absolute top-4 right-4 bg-background/90 backdrop-blur-sm">{reward.badge}</Badge>

                    {/* Icon overlay */}
                    <div
                      className={`absolute bottom-4 left-4 p-3 rounded-xl bg-gradient-to-br ${reward.color} shadow-lg`}
                    >
                      <reward.icon className="h-6 w-6 text-white" />
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <h3 className="font-bold text-xl mb-2 text-balance">{reward.title}</h3>
                    <p className="text-muted-foreground leading-relaxed text-pretty">{reward.description}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
