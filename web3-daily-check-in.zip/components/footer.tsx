"use client"

import { Hexagon, Twitter, Github, BookOpen } from "lucide-react"
import Link from "next/link"
import { motion } from "framer-motion"

export function Footer() {
  const socialLinks = [
    { icon: Twitter, href: "https://twitter.com", label: "Twitter" },
    { icon: Github, href: "https://github.com", label: "GitHub" },
    { icon: BookOpen, href: "#", label: "Docs" },
  ]

  return (
    <footer className="border-t border-border/40 bg-background/95 backdrop-blur-lg relative">
      <div className="container mx-auto px-4 py-16">
        <div className="grid gap-12 md:grid-cols-4">
          {/* Brand section */}
          <div className="md:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4 group">
              <motion.div whileHover={{ rotate: 180 }} transition={{ duration: 0.3 }}>
                <Hexagon className="h-8 w-8 fill-primary text-primary" />
              </motion.div>
              <span className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Arc Chek-IN
              </span>
            </Link>
            <p className="text-muted-foreground max-w-sm leading-relaxed mb-6">
              Daily Web3 rewards platform on ARC TestNet. Progressive wallet integration with free test mode. Start
              earning today, no wallet required.
            </p>

            {/* Social links */}
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <motion.a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.1, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted hover:bg-primary hover:text-primary-foreground transition-colors"
                  aria-label={social.label}
                >
                  <social.icon className="h-5 w-5" />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Platform links */}
          <div>
            <h4 className="font-bold mb-4 text-lg">Platform</h4>
            <ul className="space-y-3 text-muted-foreground">
              <li>
                <Link href="/" className="hover:text-primary transition-colors inline-block">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="hover:text-primary transition-colors inline-block">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors inline-block">
                  Rewards
                </Link>
              </li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors inline-block">
                  Leaderboard
                </Link>
              </li>
            </ul>
          </div>

          {/* Network info */}
          <div>
            <h4 className="font-bold mb-4 text-lg">Network</h4>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-secondary animate-pulse" />
                ARC TestNet
              </li>
              <li>Status: Active</li>
              <li>Chain ID: 1234</li>
              <li>
                <Link href="#" className="hover:text-primary transition-colors inline-block">
                  Documentation
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-8 border-t border-border/40 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} Arc Chek-IN. Built for ARC TestNet.</p>
          <div className="flex gap-6">
            <Link href="#" className="hover:text-primary transition-colors">
              Privacy Policy
            </Link>
            <Link href="#" className="hover:text-primary transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
