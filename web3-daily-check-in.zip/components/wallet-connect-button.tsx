"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Wallet, LogOut, ShieldCheck, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { useStore } from "@/lib/store"
import { getTranslations } from "@/lib/i18n"
import { connectWallet, signMessage, formatAddress } from "@/lib/web3"
import { toast } from "sonner"

export function WalletConnectButton() {
  const { locale, walletAddress, isVerified, setWalletAddress, setVerified } = useStore()
  const t = getTranslations(locale)
  const [isConnecting, setIsConnecting] = useState(false)
  const [isSigning, setIsSigning] = useState(false)

  const handleConnect = async () => {
    setIsConnecting(true)
    try {
      const wallet = await connectWallet()
      if (wallet) {
        setWalletAddress(wallet.address)
        toast.success(t.wallet.connected, {
          description: formatAddress(wallet.address),
        })
      }
    } catch (error) {
      toast.error("Failed to connect wallet", {
        description: error instanceof Error ? error.message : "Unknown error",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  const handleDisconnect = () => {
    setWalletAddress(null)
    setVerified(false)
    toast.info(t.wallet.disconnect)
  }

  const handleSign = async () => {
    if (!walletAddress) return

    setIsSigning(true)
    try {
      const message = `Arc Chek-IN Verification\n\nSign this message to verify your wallet ownership.\n\nWallet: ${walletAddress}\nTimestamp: ${Date.now()}`
      const signature = await signMessage(message)

      if (signature) {
        setVerified(true)
        toast.success(t.wallet.verified, {
          description: "You now earn bonus points!",
        })
      }
    } catch (error) {
      toast.error("Failed to sign message", {
        description: error instanceof Error ? error.message : "Unknown error",
      })
    } finally {
      setIsSigning(false)
    }
  }

  if (!walletAddress) {
    return (
      <Button onClick={handleConnect} disabled={isConnecting} className="gap-2">
        {isConnecting ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Connecting...
          </>
        ) : (
          <>
            <Wallet className="h-4 w-4" />
            {t.wallet.connect}
          </>
        )}
      </Button>
    )
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="gap-2 bg-transparent">
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 0.5, repeat: Number.POSITIVE_INFINITY, repeatDelay: 3 }}
          >
            <Wallet className="h-4 w-4" />
          </motion.div>
          <span className="hidden sm:inline">{formatAddress(walletAddress)}</span>
          {isVerified && <ShieldCheck className="h-4 w-4 text-accent" />}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <div className="px-2 py-1.5">
          <p className="text-sm font-medium">Wallet Connected</p>
          <p className="text-xs text-muted-foreground">{formatAddress(walletAddress)}</p>
        </div>
        <DropdownMenuSeparator />
        {!isVerified && (
          <DropdownMenuItem onClick={handleSign} disabled={isSigning}>
            <ShieldCheck className="mr-2 h-4 w-4" />
            {isSigning ? "Signing..." : t.wallet.sign}
          </DropdownMenuItem>
        )}
        {isVerified && (
          <DropdownMenuItem disabled>
            <ShieldCheck className="mr-2 h-4 w-4 text-accent" />
            {t.wallet.verified}
          </DropdownMenuItem>
        )}
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleDisconnect} className="text-destructive focus:text-destructive">
          <LogOut className="mr-2 h-4 w-4" />
          {t.wallet.disconnect}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
