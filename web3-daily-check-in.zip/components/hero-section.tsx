"use client"

import { motion } from "framer-motion"
import { ArrowRight, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useStore } from "@/lib/store"
import { getTranslations } from "@/lib/i18n"
import Link from "next/link"

export function HeroSection() {
  const { locale, status } = useStore()
  const t = getTranslations(locale)

  const isTestMode = status === "testUser" || status === "guest"

  return (
    <section className="relative overflow-hidden py-20 md:py-32">
      {/* Animated background gradient */}
      <div className="absolute inset-0 -z-10">
        <motion.div
          animate={{
            background: [
              "radial-gradient(circle at 20% 50%, rgba(99, 102, 241, 0.15) 0%, transparent 50%)",
              "radial-gradient(circle at 80% 50%, rgba(34, 197, 94, 0.15) 0%, transparent 50%)",
              "radial-gradient(circle at 50% 80%, rgba(236, 72, 153, 0.15) 0%, transparent 50%)",
              "radial-gradient(circle at 20% 50%, rgba(99, 102, 241, 0.15) 0%, transparent 50%)",
            ],
          }}
          transition={{ duration: 10, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
          className="h-full w-full"
        />
      </div>

      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center text-center">
          {/* Test Mode Badge */}
          {isTestMode && (
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
              <Badge variant="secondary" className="mb-6 gap-1 bg-secondary/20 text-secondary hover:bg-secondary/30">
                <Sparkles className="h-3 w-3" />
                {t.hero.testMode}
              </Badge>
            </motion.div>
          )}

          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mb-6 max-w-4xl text-balance text-5xl font-bold tracking-tight md:text-6xl lg:text-7xl"
          >
            <span className="bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
              {t.hero.title}
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="mb-8 max-w-2xl text-pretty text-lg text-muted-foreground md:text-xl"
          >
            {t.hero.subtitle}
          </motion.p>

          {/* CTA Button */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
            <Button asChild size="lg" className="group gap-2">
              <Link href="/dashboard">
                {t.hero.cta}
                <motion.div animate={{ x: [0, 5, 0] }} transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}>
                  <ArrowRight className="h-4 w-4" />
                </motion.div>
              </Link>
            </Button>
          </motion.div>

          {/* Floating cards animation */}
          <div className="relative mt-20 w-full max-w-5xl">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.7, duration: 0.8 }}
              className="relative aspect-video w-full overflow-hidden rounded-2xl border border-border/50 bg-card/50 backdrop-blur-sm shadow-2xl"
            >
              <div className="flex h-full items-center justify-center">
                <div className="grid grid-cols-3 gap-4 p-8">
                  {[
                    { label: "Daily Check-ins", color: "from-primary/20 to-primary/5" },
                    { label: "Earn Rewards", color: "from-secondary/20 to-secondary/5" },
                    { label: "Web3 Ready", color: "from-accent/20 to-accent/5" },
                  ].map((item, i) => (
                    <motion.div
                      key={item.label}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.9 + i * 0.1 }}
                      whileHover={{ scale: 1.05, y: -5 }}
                      className={`flex h-32 items-center justify-center rounded-xl bg-gradient-to-br ${item.color} border border-border/50 p-4 text-center font-semibold`}
                    >
                      {item.label}
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}
