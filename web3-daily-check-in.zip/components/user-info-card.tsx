"use client"

import { motion } from "framer-motion"
import { User, Wallet } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { getTranslations } from "@/lib/i18n"
import { formatAddress } from "@/lib/web3"
import { StatusBadge } from "@/components/status-badge"

export function UserInfoCard() {
  const { locale, walletAddress } = useStore()
  const t = getTranslations(locale)

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <User className="h-5 w-5" />
            {t.dashboard.status}
          </span>
          <StatusBadge />
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {walletAddress && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-3">
              <div className="rounded-lg bg-primary/10 p-2">
                <Wallet className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">{t.dashboard.walletAddress}</p>
                <p className="font-mono font-semibold">{formatAddress(walletAddress)}</p>
              </div>
            </motion.div>
          )}

          <div className="rounded-lg bg-muted/50 p-4 space-y-2">
            <p className="text-sm text-muted-foreground">Daily Rewards</p>
            <p className="text-2xl font-bold">
              +{useStore.getState().isVerified ? "15" : "10"} <span className="text-base font-normal">points/day</span>
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
