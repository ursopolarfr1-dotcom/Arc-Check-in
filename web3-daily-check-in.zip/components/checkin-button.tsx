"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { CheckCircle2, Loader2, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useStore } from "@/lib/store"
import { useCountdown } from "@/lib/hooks/use-countdown"
import { getTranslations } from "@/lib/i18n"
import { toast } from "sonner"

export function CheckInButton() {
  const { locale, checkInData, performCheckIn } = useStore()
  const t = getTranslations(locale)
  const [isChecking, setIsChecking] = useState(false)

  const countdown = useCountdown(checkInData.nextCheckIn)
  const canCheckIn = countdown.isComplete

  const handleCheckIn = async () => {
    if (!canCheckIn || isChecking) return

    setIsChecking(true)

    // Simulate check-in animation
    await new Promise((resolve) => setTimeout(resolve, 1500))

    performCheckIn()
    toast.success(t.checkin.success, {
      description: `+${useStore.getState().isVerified ? 15 : 10} points`,
    })

    setIsChecking(false)
  }

  return (
    <div className="flex flex-col items-center gap-6">
      <AnimatePresence mode="wait">
        {canCheckIn ? (
          <motion.div
            key="checkin-button"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            transition={{ type: "spring", stiffness: 200, damping: 20 }}
          >
            <Button
              size="lg"
              onClick={handleCheckIn}
              disabled={isChecking}
              className="relative h-16 gap-2 overflow-hidden px-8 text-lg font-bold shadow-lg hover:shadow-xl transition-all"
            >
              <AnimatePresence mode="wait">
                {isChecking ? (
                  <motion.div
                    key="loading"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1, rotate: 360 }}
                    transition={{ duration: 0.5 }}
                  >
                    <Loader2 className="h-5 w-5 animate-spin" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="sparkles"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 200 }}
                  >
                    <Sparkles className="h-5 w-5" />
                  </motion.div>
                )}
              </AnimatePresence>
              <span>{isChecking ? "Checking in..." : t.checkin.checkInNow}</span>

              {/* Glow effect */}
              <motion.div
                className="absolute inset-0 -z-10 rounded-lg bg-primary/50 blur-xl"
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.5, 0.8, 0.5],
                }}
                transition={{
                  duration: 2,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "easeInOut",
                }}
              />
            </Button>
          </motion.div>
        ) : (
          <motion.div
            key="countdown"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            className="text-center"
          >
            <Button size="lg" disabled className="h-16 gap-2 px-8 text-lg font-bold">
              <CheckCircle2 className="h-5 w-5 text-secondary" />
              <span>Checked In</span>
            </Button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Countdown Timer */}
      {!canCheckIn && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center gap-3"
        >
          <p className="text-sm text-muted-foreground">{t.checkin.nextCheckIn}</p>
          <div className="flex items-center gap-3">
            <CountdownUnit value={countdown.hours} label={t.checkin.countdown.hours} />
            <span className="text-2xl font-bold text-muted-foreground">:</span>
            <CountdownUnit value={countdown.minutes} label={t.checkin.countdown.minutes} />
            <span className="text-2xl font-bold text-muted-foreground">:</span>
            <CountdownUnit value={countdown.seconds} label={t.checkin.countdown.seconds} />
          </div>
        </motion.div>
      )}
    </div>
  )
}

function CountdownUnit({ value, label }: { value: number; label: string }) {
  return (
    <motion.div
      key={value}
      initial={{ scale: 1.2 }}
      animate={{ scale: 1 }}
      className="flex flex-col items-center gap-1 rounded-lg border border-border bg-card p-3 min-w-[70px]"
    >
      <motion.span
        key={`value-${value}`}
        initial={{ y: -10, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="text-3xl font-bold tabular-nums"
      >
        {value.toString().padStart(2, "0")}
      </motion.span>
      <span className="text-xs text-muted-foreground uppercase tracking-wide">{label}</span>
    </motion.div>
  )
}
