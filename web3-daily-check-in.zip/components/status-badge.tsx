"use client"

import type React from "react"

import { Badge } from "@/components/ui/badge"
import { useStore } from "@/lib/store"
import { getTranslations } from "@/lib/i18n"
import { ShieldCheck, User, Sparkles, Wallet } from "lucide-react"
import type { UserStatus } from "@/lib/store"

export function StatusBadge() {
  const { locale, status } = useStore()
  const t = getTranslations(locale)

  const statusConfig: Record<
    UserStatus,
    {
      label: string
      icon: React.ElementType
      variant: "default" | "secondary" | "outline"
      className: string
    }
  > = {
    guest: {
      label: t.dashboard.guest,
      icon: User,
      variant: "outline",
      className: "gap-1",
    },
    testUser: {
      label: t.dashboard.testMode,
      icon: Sparkles,
      variant: "secondary",
      className: "gap-1 bg-secondary/20 text-secondary hover:bg-secondary/30",
    },
    web3User: {
      label: t.dashboard.web3Mode,
      icon: Wallet,
      variant: "default",
      className: "gap-1 bg-primary/20 text-primary hover:bg-primary/30",
    },
    verifiedUser: {
      label: t.dashboard.verified,
      icon: ShieldCheck,
      variant: "default",
      className: "gap-1 bg-accent/20 text-accent hover:bg-accent/30",
    },
  }

  const config = statusConfig[status]
  const Icon = config.icon

  return (
    <Badge variant={config.variant} className={config.className}>
      <Icon className="h-3 w-3" />
      {config.label}
    </Badge>
  )
}
