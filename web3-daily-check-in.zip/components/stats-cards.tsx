"use client"

import { motion } from "framer-motion"
import { Award, Calendar, Clock } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { getTranslations } from "@/lib/i18n"

export function StatsCards() {
  const { locale, checkInData } = useStore()
  const t = getTranslations(locale)

  const stats = [
    {
      icon: Award,
      label: t.dashboard.points,
      value: checkInData.points.toString(),
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      icon: Calendar,
      label: t.dashboard.totalCheckIns,
      value: checkInData.totalCheckIns.toString(),
      color: "text-secondary",
      bgColor: "bg-secondary/10",
    },
    {
      icon: Clock,
      label: t.dashboard.lastCheckIn,
      value: checkInData.lastCheckIn ? new Date(checkInData.lastCheckIn).toLocaleDateString(locale) : "—",
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-3">
      {stats.map((stat, index) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          whileHover={{ y: -5, transition: { duration: 0.2 } }}
        >
          <Card className="border-border/50 hover:border-border transition-colors">
            <CardContent className="flex items-center gap-4 p-6">
              <div className={`rounded-lg p-3 ${stat.bgColor}`}>
                <stat.icon className={`h-6 w-6 ${stat.color}`} />
              </div>
              <div className="flex-1">
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <motion.p
                  key={stat.value}
                  initial={{ scale: 1.2, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-2xl font-bold"
                >
                  {stat.value}
                </motion.p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  )
}
