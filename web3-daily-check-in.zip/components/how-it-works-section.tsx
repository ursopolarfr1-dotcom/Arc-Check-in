"use client"

import { motion } from "framer-motion"
import { CheckCircle2, Gift, Repeat } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { getTranslations } from "@/lib/i18n"

export function HowItWorksSection() {
  const { locale } = useStore()
  const t = getTranslations(locale)

  const steps = [
    {
      icon: CheckCircle2,
      title: t.howItWorks?.step1Title || "Daily Check-in",
      description: t.howItWorks?.step1Desc || "Complete your daily check-in with one click",
      color: "from-primary to-primary/50",
      iconColor: "text-primary",
      image: "/calendar-check-mark.jpg",
    },
    {
      icon: Gift,
      title: t.howItWorks?.step2Title || "Earn Points",
      description: t.howItWorks?.step2Desc || "Accumulate points for each consecutive day",
      color: "from-secondary to-secondary/50",
      iconColor: "text-secondary",
      image: "/gift-box-rewards.jpg",
    },
    {
      icon: Repeat,
      title: t.howItWorks?.step3Title || "Get Rewards",
      description: t.howItWorks?.step3Desc || "Exchange points for tokens, NFTs, and exclusive benefits",
      color: "from-accent to-accent/50",
      iconColor: "text-accent",
      image: "/trophy-rewards-nft.jpg",
    },
  ]

  return (
    <section className="py-20 relative">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold mb-4 text-balance">{t.howItWorks?.title || "How Check-in Works"}</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto text-pretty">
            {t.howItWorks?.subtitle || "Three simple steps to start earning rewards daily"}
          </p>
        </motion.div>

        <div className="grid gap-8 md:grid-cols-3 max-w-6xl mx-auto">
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2 }}
            >
              <Card className="group relative overflow-hidden border-2 hover:border-primary/50 transition-all duration-300 h-full">
                {/* Gradient overlay on hover */}
                <div
                  className={`absolute inset-0 bg-gradient-to-br ${step.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}
                />

                <CardContent className="p-6 relative">
                  {/* Step number */}
                  <div className="absolute top-4 right-4 text-5xl font-bold text-muted/10">{index + 1}</div>

                  {/* Icon with glow effect */}
                  <motion.div whileHover={{ scale: 1.1, rotate: 5 }} className="mb-6 relative">
                    <div className={`inline-flex rounded-2xl p-4 bg-gradient-to-br ${step.color} shadow-lg`}>
                      <step.icon className="h-8 w-8 text-white" />
                    </div>
                    <div
                      className={`absolute inset-0 bg-gradient-to-br ${step.color} blur-xl opacity-0 group-hover:opacity-50 transition-opacity`}
                    />
                  </motion.div>

                  {/* Image illustration */}
                  <div className="mb-4 rounded-lg overflow-hidden bg-muted/30">
                    <img
                      src={step.image || "/placeholder.svg"}
                      alt={step.title}
                      className="w-full h-40 object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                    />
                  </div>

                  <h3 className="font-bold text-xl mb-3 text-balance">{step.title}</h3>
                  <p className="text-muted-foreground leading-relaxed text-pretty">{step.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
