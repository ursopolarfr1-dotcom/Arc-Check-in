"use client"

import { motion } from "framer-motion"
import { Coins } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { getTranslations } from "@/lib/i18n"

// Mock token data - replace with actual blockchain queries
const mockTokens = [
  { symbol: "ARC", balance: "1,250.00", value: "$2,500.00", change: "+5.2%" },
  { symbol: "ETH", balance: "0.5", value: "$1,250.00", change: "+2.1%" },
  { symbol: "USDC", balance: "500.00", value: "$500.00", change: "0.0%" },
]

export function TokensDisplay() {
  const { locale, walletAddress } = useStore()
  const t = getTranslations(locale)

  const tokens = walletAddress ? mockTokens : []

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Coins className="h-5 w-5 text-primary" />
          {t.dashboard.tokens}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {tokens.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">Connect wallet to view tokens</p>
        ) : (
          <div className="space-y-4">
            {tokens.map((token, index) => (
              <motion.div
                key={token.symbol}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between p-3 rounded-lg border border-border/50 hover:border-border transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">{token.symbol.slice(0, 2)}</span>
                  </div>
                  <div>
                    <p className="font-semibold">{token.symbol}</p>
                    <p className="text-sm text-muted-foreground">{token.balance}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold">{token.value}</p>
                  <p className={`text-sm ${token.change.startsWith("+") ? "text-secondary" : "text-muted-foreground"}`}>
                    {token.change}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
