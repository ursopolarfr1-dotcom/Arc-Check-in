"use client"

import { motion } from "framer-motion"
import { Calendar, Wallet, Trophy, Shield, Globe, Zap } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { getTranslations } from "@/lib/i18n"

export function FeaturesSection() {
  const { locale } = useStore()
  const t = getTranslations(locale)

  const features = [
    {
      icon: Calendar,
      title: "Daily Check-ins",
      description: "Earn rewards every day with our automated countdown system",
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      icon: Wallet,
      title: "Web3 Ready",
      description: "Progressive wallet integration with MetaMask and WalletConnect",
      color: "text-secondary",
      bgColor: "bg-secondary/10",
    },
    {
      icon: Trophy,
      title: "Earn Rewards",
      description: "Accumulate points and unlock exclusive benefits",
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
    {
      icon: Shield,
      title: "Verified Users",
      description: "Sign messages to verify ownership and earn bonus points",
      color: "text-chart-4",
      bgColor: "bg-chart-4/10",
    },
    {
      icon: Globe,
      title: "Multi-Language",
      description: "Available in English, Portuguese, French, and Spanish",
      color: "text-chart-5",
      bgColor: "bg-chart-5/10",
    },
    {
      icon: Zap,
      title: "Test Mode",
      description: "Try everything without connecting a wallet first",
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
  ]

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Everything You Need</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A complete Web3 check-in platform with progressive features and seamless user experience
          </p>
        </motion.div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="border-border/50 hover:border-border transition-all hover:shadow-lg h-full">
                <CardContent className="p-6">
                  <div className={`inline-flex rounded-lg p-3 ${feature.bgColor} mb-4`}>
                    <feature.icon className={`h-6 w-6 ${feature.color}`} />
                  </div>
                  <h3 className="font-semibold mb-2 text-lg">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
