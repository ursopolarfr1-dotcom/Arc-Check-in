"use client"

import { motion } from "framer-motion"
import { Flame, TrendingUp, Zap } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useStore } from "@/lib/store"
import { getTranslations } from "@/lib/i18n"

export function StreakSection() {
  const { locale, checkIns } = useStore()
  const t = getTranslations(locale)

  const streakMilestones = [
    { days: 7, reward: "50 Bonus Points", icon: Flame, reached: checkIns >= 7 },
    { days: 30, reward: "Exclusive NFT", icon: TrendingUp, reached: checkIns >= 30 },
    { days: 100, reward: "Legendary Badge", icon: Zap, reached: checkIns >= 100 },
  ]

  const progress = Math.min((checkIns / 100) * 100, 100)

  return (
    <section className="py-20 relative">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 mb-4">
            <Flame className="h-8 w-8 text-accent" />
            <h2 className="text-4xl font-bold text-balance">{t.streak?.title || "Streak & Bonus Rewards"}</h2>
          </div>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto text-pretty">
            {t.streak?.subtitle || "Keep your streak alive to unlock amazing bonuses"}
          </p>
        </motion.div>

        {/* Progress visualization */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto mb-12"
        >
          <Card className="border-2 bg-gradient-to-br from-primary/5 via-accent/5 to-secondary/5">
            <CardContent className="p-8">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-bold">
                    {checkIns} {t.streak?.daysLabel || "Days"}
                  </h3>
                  <p className="text-sm text-muted-foreground">{t.streak?.currentStreak || "Current Streak"}</p>
                </div>
                <motion.div
                  animate={{ rotate: [0, 5, -5, 0] }}
                  transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                  className="p-4 rounded-full bg-gradient-to-br from-accent to-accent/50"
                >
                  <Flame className="h-8 w-8 text-white" />
                </motion.div>
              </div>

              {/* Animated progress bar */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>0</span>
                  <span>100 {t.streak?.daysLabel || "days"}</span>
                </div>
                <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
                  <Progress value={progress} className="h-3" />
                </motion.div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Milestone cards */}
        <div className="grid gap-6 md:grid-cols-3 max-w-5xl mx-auto">
          {streakMilestones.map((milestone, index) => (
            <motion.div
              key={milestone.days}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <Card
                className={`relative overflow-hidden transition-all duration-300 ${
                  milestone.reached
                    ? "border-primary bg-gradient-to-br from-primary/10 to-transparent"
                    : "border-border/50 hover:border-border"
                }`}
              >
                <CardContent className="p-6">
                  {milestone.reached && (
                    <div className="absolute top-2 right-2">
                      <div className="h-6 w-6 rounded-full bg-primary flex items-center justify-center">
                        <span className="text-primary-foreground text-xs">✓</span>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center gap-3 mb-4">
                    <div
                      className={`p-3 rounded-lg ${
                        milestone.reached ? "bg-primary text-primary-foreground" : "bg-muted"
                      }`}
                    >
                      <milestone.icon className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold">{milestone.days}</p>
                      <p className="text-sm text-muted-foreground">{t.streak?.daysLabel || "Days"}</p>
                    </div>
                  </div>

                  <p className="font-semibold text-balance">{milestone.reward}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
