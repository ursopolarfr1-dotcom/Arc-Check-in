"use client"

import { motion } from "framer-motion"
import { ImageIcon } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useStore } from "@/lib/store"
import { getTranslations } from "@/lib/i18n"

// Mock NFT data - replace with actual blockchain queries
const mockNFTs = [
  {
    id: 1,
    name: "Arc Genesis #123",
    collection: "Arc Genesis",
    image: "/abstract-digital-art-nft.png",
  },
  {
    id: 2,
    name: "Crypto Punk #456",
    collection: "Crypto Punks",
    image: "/pixel-art-character.png",
  },
  {
    id: 3,
    name: "Bored Ape #789",
    collection: "BAYC",
    image: "/ape-cartoon.jpg",
  },
]

export function NFTsDisplay() {
  const { locale, walletAddress } = useStore()
  const t = getTranslations(locale)

  const nfts = walletAddress ? mockNFTs : []

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <ImageIcon className="h-5 w-5 text-accent" />
          {t.dashboard.nfts}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {nfts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="rounded-full bg-muted p-4 mb-4">
              <ImageIcon className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground">
              {walletAddress ? t.dashboard.noNFTs : "Connect wallet to view NFTs"}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {nfts.map((nft, index) => (
              <motion.div
                key={nft.id}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05, y: -5 }}
                className="group cursor-pointer"
              >
                <div className="relative aspect-square rounded-lg overflow-hidden border border-border/50 hover:border-border transition-colors bg-muted">
                  <img src={nft.image || "/placeholder.svg"} alt={nft.name} className="h-full w-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-3">
                    <p className="text-white text-sm font-semibold">{nft.name}</p>
                    <p className="text-white/80 text-xs">{nft.collection}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
