"use client"

import { Navbar } from "@/components/navbar"
import { AnimatedBackground } from "@/components/animated-background"
import { HeroSection } from "@/components/hero-section"
import { HowItWorksSection } from "@/components/how-it-works-section"
import { RewardsSection } from "@/components/rewards-section"
import { StreakSection } from "@/components/streak-section"
import { FeaturesSection } from "@/components/features-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen relative">
      <AnimatedBackground />
      <Navbar />
      <main>
        <HeroSection />
        <HowItWorksSection />
        <RewardsSection />
        <StreakSection />
        <FeaturesSection />
      </main>
      <Footer />
    </div>
  )
}
