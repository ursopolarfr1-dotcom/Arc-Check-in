"use client"

import { Navbar } from "@/components/navbar"
import { AnimatedBackground } from "@/components/animated-background"
import { CheckInButton } from "@/components/checkin-button"
import { StatsCards } from "@/components/stats-cards"
import { UserInfoCard } from "@/components/user-info-card"
import { TokensDisplay } from "@/components/tokens-display"
import { NFTsDisplay } from "@/components/nfts-display"
import { Footer } from "@/components/footer"

export default function DashboardPage() {
  return (
    <div className="min-h-screen flex flex-col relative">
      <AnimatedBackground />
      <Navbar />
      <main className="container mx-auto px-4 py-8 flex-1 relative">
        <div className="space-y-8">
          {/* Header Section */}
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground">Check in daily to earn rewards on ARC TestNet</p>
          </div>

          {/* Check-in Button */}
          <div className="flex justify-center">
            <CheckInButton />
          </div>

          {/* Stats Cards */}
          <StatsCards />

          {/* Main Grid */}
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="lg:col-span-1">
              <UserInfoCard />
            </div>
            <div className="lg:col-span-2 space-y-6">
              <TokensDisplay />
              <NFTsDisplay />
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
