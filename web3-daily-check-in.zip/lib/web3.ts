// Web3 integration utilities for ARC TestNet
// This is prepared for full wagmi/viem integration

export interface WalletState {
  address: string
  chainId: number
  isConnected: boolean
}

// Mock wallet connection for demonstration
// Replace with actual wagmi hooks when deploying to ARC TestNet
export async function connectWallet(): Promise<WalletState | null> {
  if (typeof window === "undefined" || !window.ethereum) {
    throw new Error("No Web3 wallet detected. Please install MetaMask.")
  }

  try {
    // Request account access
    const accounts = await window.ethereum.request({
      method: "eth_requestAccounts",
    })

    const chainId = await window.ethereum.request({
      method: "eth_chainId",
    })

    return {
      address: accounts[0],
      chainId: Number.parseInt(chainId, 16),
      isConnected: true,
    }
  } catch (error) {
    console.error("Failed to connect wallet:", error)
    return null
  }
}

export async function signMessage(message: string): Promise<string | null> {
  if (typeof window === "undefined" || !window.ethereum) {
    throw new Error("No Web3 wallet detected")
  }

  try {
    const accounts = await window.ethereum.request({
      method: "eth_accounts",
    })

    if (accounts.length === 0) {
      throw new Error("No wallet connected")
    }

    const signature = await window.ethereum.request({
      method: "personal_sign",
      params: [message, accounts[0]],
    })

    return signature
  } catch (error) {
    console.error("Failed to sign message:", error)
    return null
  }
}

export function formatAddress(address: string): string {
  if (!address) return ""
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

// TypeScript declarations for window.ethereum
declare global {
  interface Window {
    ethereum?: {
      request: (args: { method: string; params?: unknown[] }) => Promise<any>
      on?: (event: string, callback: (...args: any[]) => void) => void
      removeListener?: (event: string, callback: (...args: any[]) => void) => void
    }
  }
}
