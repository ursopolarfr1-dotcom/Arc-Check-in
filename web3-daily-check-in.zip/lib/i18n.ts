export type Locale = "en" | "pt" | "fr" | "es"

export const locales: Locale[] = ["en", "pt", "fr", "es"]

export const localeNames: Record<Locale, string> = {
  en: "English",
  pt: "Português",
  fr: "Français",
  es: "Español",
}

export interface Translations {
  nav: {
    home: string
    dashboard: string
    about: string
  }
  hero: {
    title: string
    subtitle: string
    cta: string
    testMode: string
  }
  howItWorks?: {
    title: string
    subtitle: string
    step1Title: string
    step1Desc: string
    step2Title: string
    step2Desc: string
    step3Title: string
    step3Desc: string
  }
  rewards?: {
    title: string
    subtitle: string
    tokensTitle: string
    tokensDesc: string
    nftsTitle: string
    nftsDesc: string
    badgesTitle: string
    badgesDesc: string
  }
  streak?: {
    title: string
    subtitle: string
    currentStreak: string
    daysLabel: string
  }
  checkin: {
    checkInNow: string
    nextCheckIn: string
    success: string
    countdown: {
      hours: string
      minutes: string
      seconds: string
    }
  }
  wallet: {
    connect: string
    disconnect: string
    connected: string
    sign: string
    verified: string
  }
  dashboard: {
    title: string
    status: string
    guest: string
    testMode: string
    web3Mode: string
    verified: string
    points: string
    totalCheckIns: string
    lastCheckIn: string
    walletAddress: string
    tokens: string
    nfts: string
    noNFTs: string
  }
  theme: {
    light: string
    dark: string
    toggle: string
  }
}

export const translations: Record<Locale, Translations> = {
  en: {
    nav: {
      home: "Home",
      dashboard: "Dashboard",
      about: "About",
    },
    hero: {
      title: "Arc Daily Check-in",
      subtitle: "Earn rewards daily on ARC TestNet. Test mode available - no wallet required.",
      cta: "Start Checking In",
      testMode: "Test Mode",
    },
    howItWorks: {
      title: "How Check-in Works",
      subtitle: "Three simple steps to start earning rewards daily",
      step1Title: "Daily Check-in",
      step1Desc: "Complete your daily check-in with one click and start your streak",
      step2Title: "Earn Points",
      step2Desc: "Accumulate points for each consecutive day you check in",
      step3Title: "Get Rewards",
      step3Desc: "Exchange points for tokens, NFTs, and exclusive benefits",
    },
    rewards: {
      title: "Exclusive Rewards",
      subtitle: "Multiple ways to earn and unlock valuable rewards",
      tokensTitle: "ARC Tokens",
      tokensDesc: "Earn native tokens with every check-in and maintain your streak",
      nftsTitle: "Exclusive NFTs",
      nftsDesc: "Unlock rare NFTs by maintaining streaks and reaching milestones",
      badgesTitle: "Achievement Badges",
      badgesDesc: "Collect special badges for milestones and special events",
    },
    streak: {
      title: "Streak & Bonus Rewards",
      subtitle: "Keep your streak alive to unlock amazing bonuses",
      currentStreak: "Current Streak",
      daysLabel: "Days",
    },
    checkin: {
      checkInNow: "Check-in Now",
      nextCheckIn: "Next check-in in",
      success: "Check-in successful!",
      countdown: {
        hours: "hours",
        minutes: "minutes",
        seconds: "seconds",
      },
    },
    wallet: {
      connect: "Connect Wallet",
      disconnect: "Disconnect",
      connected: "Connected",
      sign: "Sign Message",
      verified: "Verified",
    },
    dashboard: {
      title: "Dashboard",
      status: "Status",
      guest: "Guest",
      testMode: "Test Mode",
      web3Mode: "Web3 Mode",
      verified: "Verified",
      points: "Points",
      totalCheckIns: "Total Check-ins",
      lastCheckIn: "Last Check-in",
      walletAddress: "Wallet Address",
      tokens: "Tokens",
      nfts: "NFTs",
      noNFTs: "No NFTs to display",
    },
    theme: {
      light: "Light",
      dark: "Dark",
      toggle: "Toggle theme",
    },
  },
  pt: {
    nav: {
      home: "Início",
      dashboard: "Painel",
      about: "Sobre",
    },
    hero: {
      title: "Check-in Diário Arc",
      subtitle: "Ganhe recompensas diárias na ARC TestNet. Modo teste disponível - carteira não obrigatória.",
      cta: "Começar Check-ins",
      testMode: "Modo Teste",
    },
    howItWorks: {
      title: "Como Funciona o Check-in",
      subtitle: "Três passos simples para começar a ganhar recompensas diárias",
      step1Title: "Check-in Diário",
      step1Desc: "Complete seu check-in diário com um clique e inicie sua sequência",
      step2Title: "Ganhe Pontos",
      step2Desc: "Acumule pontos por cada dia consecutivo de check-in",
      step3Title: "Receba Recompensas",
      step3Desc: "Troque pontos por tokens, NFTs e benefícios exclusivos",
    },
    rewards: {
      title: "Recompensas Exclusivas",
      subtitle: "Múltiplas formas de ganhar e desbloquear recompensas valiosas",
      tokensTitle: "Tokens ARC",
      tokensDesc: "Ganhe tokens nativos a cada check-in e mantenha sua sequência",
      nftsTitle: "NFTs Exclusivos",
      nftsDesc: "Desbloqueie NFTs raros mantendo sequências e alcançando marcos",
      badgesTitle: "Badges de Conquistas",
      badgesDesc: "Colecione badges especiais por marcos e eventos especiais",
    },
    streak: {
      title: "Sequência e Bônus",
      subtitle: "Mantenha sua sequência viva para desbloquear bônus incríveis",
      currentStreak: "Sequência Atual",
      daysLabel: "Dias",
    },
    checkin: {
      checkInNow: "Fazer Check-in",
      nextCheckIn: "Próximo check-in em",
      success: "Check-in realizado com sucesso!",
      countdown: {
        hours: "horas",
        minutes: "minutos",
        seconds: "segundos",
      },
    },
    wallet: {
      connect: "Conectar Carteira",
      disconnect: "Desconectar",
      connected: "Conectada",
      sign: "Assinar Mensagem",
      verified: "Verificado",
    },
    dashboard: {
      title: "Painel",
      status: "Status",
      guest: "Convidado",
      testMode: "Modo Teste",
      web3Mode: "Modo Web3",
      verified: "Verificado",
      points: "Pontos",
      totalCheckIns: "Total de Check-ins",
      lastCheckIn: "Último Check-in",
      walletAddress: "Endereço da Carteira",
      tokens: "Tokens",
      nfts: "NFTs",
      noNFTs: "Nenhum NFT para exibir",
    },
    theme: {
      light: "Claro",
      dark: "Escuro",
      toggle: "Alternar tema",
    },
  },
  fr: {
    nav: {
      home: "Accueil",
      dashboard: "Tableau de bord",
      about: "À propos",
    },
    hero: {
      title: "Check-in Quotidien Arc",
      subtitle: "Gagnez des récompenses quotidiennes sur ARC TestNet. Mode test disponible - portefeuille non requis.",
      cta: "Commencer les Check-ins",
      testMode: "Mode Test",
    },
    howItWorks: {
      title: "Comment Fonctionne le Check-in",
      subtitle: "Trois étapes simples pour commencer à gagner des récompenses quotidiennes",
      step1Title: "Check-in Quotidien",
      step1Desc: "Complétez votre check-in quotidien en un clic et commencez votre série",
      step2Title: "Gagnez des Points",
      step2Desc: "Accumulez des points pour chaque jour consécutif de check-in",
      step3Title: "Obtenez des Récompenses",
      step3Desc: "Échangez des points contre des jetons, des NFTs et des avantages exclusifs",
    },
    rewards: {
      title: "Récompenses Exclusives",
      subtitle: "Plusieurs façons de gagner et débloquer des récompenses précieuses",
      tokensTitle: "Jetons ARC",
      tokensDesc: "Gagnez des jetons natifs à chaque check-in et maintenez votre série",
      nftsTitle: "NFTs Exclusifs",
      nftsDesc: "Débloquez des NFTs rares en maintenant des séries et en atteignant des jalons",
      badgesTitle: "Badges de Réussite",
      badgesDesc: "Collectionnez des badges spéciaux pour les jalons et événements spéciaux",
    },
    streak: {
      title: "Série et Bonus",
      subtitle: "Gardez votre série vivante pour débloquer des bonus incroyables",
      currentStreak: "Série Actuelle",
      daysLabel: "Jours",
    },
    checkin: {
      checkInNow: "S'enregistrer maintenant",
      nextCheckIn: "Prochain check-in dans",
      success: "Check-in réussi!",
      countdown: {
        hours: "heures",
        minutes: "minutes",
        seconds: "secondes",
      },
    },
    wallet: {
      connect: "Connecter Portefeuille",
      disconnect: "Déconnecter",
      connected: "Connecté",
      sign: "Signer Message",
      verified: "Vérifié",
    },
    dashboard: {
      title: "Tableau de bord",
      status: "Statut",
      guest: "Invité",
      testMode: "Mode Test",
      web3Mode: "Mode Web3",
      verified: "Vérifié",
      points: "Points",
      totalCheckIns: "Total des Check-ins",
      lastCheckIn: "Dernier Check-in",
      walletAddress: "Adresse du Portefeuille",
      tokens: "Jetons",
      nfts: "NFTs",
      noNFTs: "Aucun NFT à afficher",
    },
    theme: {
      light: "Clair",
      dark: "Sombre",
      toggle: "Basculer le thème",
    },
  },
  es: {
    nav: {
      home: "Inicio",
      dashboard: "Panel",
      about: "Acerca de",
    },
    hero: {
      title: "Check-in Diario Arc",
      subtitle: "Gana recompensas diarias en ARC TestNet. Modo de prueba disponible - billetera no requerida.",
      cta: "Comenzar Check-ins",
      testMode: "Modo Prueba",
    },
    howItWorks: {
      title: "Cómo Funciona el Check-in",
      subtitle: "Tres pasos simples para comenzar a ganar recompensas diarias",
      step1Title: "Check-in Diario",
      step1Desc: "Completa tu check-in diario con un clic e inicia tu racha",
      step2Title: "Gana Puntos",
      step2Desc: "Acumula puntos por cada día consecutivo de check-in",
      step3Title: "Obtén Recompensas",
      step3Desc: "Intercambia puntos por tokens, NFTs y beneficios exclusivos",
    },
    rewards: {
      title: "Recompensas Exclusivas",
      subtitle: "Múltiples formas de ganar y desbloquear recompensas valiosas",
      tokensTitle: "Tokens ARC",
      tokensDesc: "Gana tokens nativos con cada check-in y mantén tu racha",
      nftsTitle: "NFTs Exclusivos",
      nftsDesc: "Desbloquea NFTs raros manteniendo rachas y alcanzando hitos",
      badgesTitle: "Insignias de Logros",
      badgesDesc: "Colecciona insignias especiales por hitos y eventos especiales",
    },
    streak: {
      title: "Racha y Bonificaciones",
      subtitle: "Mantén tu racha viva para desbloquear bonificaciones increíbles",
      currentStreak: "Racha Actual",
      daysLabel: "Días",
    },
    checkin: {
      checkInNow: "Registrarse Ahora",
      nextCheckIn: "Próximo check-in en",
      success: "¡Check-in exitoso!",
      countdown: {
        hours: "horas",
        minutes: "minutos",
        seconds: "segundos",
      },
    },
    wallet: {
      connect: "Conectar Billetera",
      disconnect: "Desconectar",
      connected: "Conectado",
      sign: "Firmar Mensaje",
      verified: "Verificado",
    },
    dashboard: {
      title: "Panel",
      status: "Estado",
      guest: "Invitado",
      testMode: "Modo Prueba",
      web3Mode: "Modo Web3",
      verified: "Verificado",
      points: "Puntos",
      totalCheckIns: "Total de Check-ins",
      lastCheckIn: "Último Check-in",
      walletAddress: "Dirección de Billetera",
      tokens: "Tokens",
      nfts: "NFTs",
      noNFTs: "No hay NFTs para mostrar",
    },
    theme: {
      light: "Claro",
      dark: "Oscuro",
      toggle: "Cambiar tema",
    },
  },
}

export function getTranslations(locale: Locale): Translations {
  return translations[locale] || translations.en
}
