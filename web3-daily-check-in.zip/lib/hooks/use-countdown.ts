"use client"

import { useState, useEffect } from "react"

export interface CountdownTime {
  hours: number
  minutes: number
  seconds: number
  isComplete: boolean
}

export function useCountdown(targetTime: number | null): CountdownTime {
  const [time, setTime] = useState<CountdownTime>({
    hours: 0,
    minutes: 0,
    seconds: 0,
    isComplete: true,
  })

  useEffect(() => {
    if (!targetTime) {
      setTime({ hours: 0, minutes: 0, seconds: 0, isComplete: true })
      return
    }

    const calculateTime = () => {
      const now = Date.now()
      const difference = targetTime - now

      if (difference <= 0) {
        setTime({ hours: 0, minutes: 0, seconds: 0, isComplete: true })
        return
      }

      const hours = Math.floor(difference / (1000 * 60 * 60))
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((difference % (1000 * 60)) / 1000)

      setTime({ hours, minutes, seconds, isComplete: false })
    }

    calculateTime()
    const interval = setInterval(calculateTime, 1000)

    return () => clearInterval(interval)
  }, [targetTime])

  return time
}
