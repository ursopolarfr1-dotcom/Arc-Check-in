import { create } from "zustand"
import { persist } from "zustand/middleware"
import type { Locale } from "./i18n"

export type UserStatus = "guest" | "testUser" | "web3User" | "verifiedUser"

export interface CheckInData {
  lastCheckIn: number | null
  nextCheckIn: number | null
  totalCheckIns: number
  points: number
}

export interface UserState {
  status: UserStatus
  locale: Locale
  theme: "light" | "dark"
  walletAddress: string | null
  isVerified: boolean
  checkInData: CheckInData
  setStatus: (status: UserStatus) => void
  setLocale: (locale: Locale) => void
  setTheme: (theme: "light" | "dark") => void
  setWalletAddress: (address: string | null) => void
  setVerified: (verified: boolean) => void
  performCheckIn: () => void
  resetCheckInData: () => void
}

const getNextMidnight = () => {
  const now = new Date()
  const tomorrow = new Date(now)
  tomorrow.setDate(tomorrow.getDate() + 1)
  tomorrow.setHours(0, 0, 0, 0)
  return tomorrow.getTime()
}

export const useStore = create<UserState>()(
  persist(
    (set, get) => ({
      status: "guest",
      locale: "en",
      theme: "dark",
      walletAddress: null,
      isVerified: false,
      checkInData: {
        lastCheckIn: null,
        nextCheckIn: null,
        totalCheckIns: 0,
        points: 0,
      },
      setStatus: (status) => set({ status }),
      setLocale: (locale) => set({ locale }),
      setTheme: (theme) => {
        set({ theme })
        if (typeof document !== "undefined") {
          if (theme === "dark") {
            document.documentElement.classList.add("dark")
          } else {
            document.documentElement.classList.remove("dark")
          }
        }
      },
      setWalletAddress: (address) => {
        set({ walletAddress: address })
        if (address) {
          set({ status: "web3User" })
        }
      },
      setVerified: (verified) => {
        set({ isVerified: verified })
        if (verified) {
          set({ status: "verifiedUser" })
        }
      },
      performCheckIn: () => {
        const now = Date.now()
        const nextMidnight = getNextMidnight()
        const state = get()

        const bonusPoints = state.isVerified ? 15 : 10

        set({
          checkInData: {
            lastCheckIn: now,
            nextCheckIn: nextMidnight,
            totalCheckIns: state.checkInData.totalCheckIns + 1,
            points: state.checkInData.points + bonusPoints,
          },
          status: state.walletAddress ? (state.isVerified ? "verifiedUser" : "web3User") : "testUser",
        })
      },
      resetCheckInData: () => {
        set({
          checkInData: {
            lastCheckIn: null,
            nextCheckIn: null,
            totalCheckIns: 0,
            points: 0,
          },
        })
      },
    }),
    {
      name: "arc-checkin-storage",
    },
  ),
)
