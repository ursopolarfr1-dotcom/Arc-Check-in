# Arc Chek-IN - Daily Web3 Rewards Platform

A modern, animated Web3 daily check-in platform built for ARC TestNet with progressive wallet integration.

## Features

- **Daily Check-ins**: Automated countdown system that resets at midnight
- **Progressive Web3**: Free test mode, no wallet required to try
- **Multi-Language**: Full i18n support (English, Portuguese, French, Spanish)
- **Wallet Integration**: MetaMask support with message signing for verification
- **Theme Support**: Light and dark modes with smooth transitions
- **Animated UI**: Framer Motion animations throughout
- **User States**: Guest → Test User → Web3 User → Verified User progression

## Tech Stack

- Next.js 16 (App Router)
- TypeScript
- Tailwind CSS v4
- shadcn/ui components
- Framer Motion
- Zustand (State Management)
- Sonner (Toast Notifications)

## Getting Started

1. Install dependencies:
```bash
npm install
```

2. Run development server:
```bash
npm run dev
```

3. Open [http://localhost:3000](http://localhost:3000)

## User Flow

1. **Guest Mode**: Browse and explore without connecting
2. **Test Mode**: Make test check-ins with localStorage
3. **Web3 Mode**: Connect wallet to save progress on-chain
4. **Verified Mode**: Sign message for bonus rewards

## Check-in System

- One check-in per 24 hours
- Real-time countdown timer
- Automatic unlock at midnight
- Points: 10 per check-in (15 for verified users)

## Web3 Integration

Prepared for ARC TestNet deployment:
- Wallet connection via MetaMask
- Message signing for verification
- Token and NFT display (mock data ready for RPC integration)

## Deployment

Built for Vercel deployment with automatic optimizations.
